const mysql = require('mysql');

// Configuración de la conexión a la base de datos


module.exports = {};