# WebExpress
Primero que nada tener instalado node y npm-

cuando los tengamos instalado debemos intalar las dependencias, con el comando:+
npm install 
(debemos estar dentro de la carpeta del proyecto)

cuando se tiene instalado se puede iniciar con:

node src/app.js

el archivo a ejecutar con nodejs es app.js , esto abre un servidor http en el puerto 555
